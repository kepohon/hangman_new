### What is this?

A long description for example project.