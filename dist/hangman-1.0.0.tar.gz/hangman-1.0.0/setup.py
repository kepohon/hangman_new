#!/usr/bin/env python
# -*- coding: utf-8 -*-

from setuptools import setup


setup()